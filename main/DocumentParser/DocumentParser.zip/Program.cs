﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Newtonsoft.Json;



namespace DocumentParser
{
    /// <summary>
    /// 
    /// </summary>
    static class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            
            const string path = @"C:\Laptop Backup\Pritam\Docs\Resume_Pritam Paul.docx";

            using (var document = WordprocessingDocument.Open(path, false))
            {
                ProcessHeaders(document);
                ProcessBody(document);
            }

        }

        /// <summary>
        /// Processes the headers.
        /// </summary>
        /// <param name="document">The document.</param>
        private static void ProcessHeaders(WordprocessingDocument document)
        {
            var mainDoc = document.MainDocumentPart.Document;
            var headers = mainDoc.Descendants<HeaderReference>().Count();
        }

        /// <summary>
        /// Processes the body.
        /// </summary>
        /// <param name="document">The document.</param>
        private static void ProcessBody(WordprocessingDocument document)
        {
            var wordDictionary = new List<string>
                {
                    "experience",
                    "certifications",
                    "achievements",
                    "technical",
                    "education",
                    "personal"
                };

            var body = document.MainDocumentPart.Document.Body;

            var defaultStyleName =
                document.MainDocumentPart.StyleDefinitionsPart.Styles.Elements<Style>()
                        .First(style => style.Type == StyleValues.Paragraph &&
                                        style.Default)
                        .StyleId.Value;


            var styles = body.Elements().Select((p, i) =>
                {
                    var styleNode = p.Descendants<ParagraphStyleId>().FirstOrDefault();
                    var styleName = styleNode != null ? styleNode.Val.Value : defaultStyleName;

                    return new WordDocumentModel
                        {
                            Element = p,
                            Index = i,
                            StyleName = styleName
                        };
                });

            var documentModel = styles.Select(i =>
                {
                    string text;

                    if (i.Element.GetType() == typeof(Paragraph))
                        text = i.Element
                                .Descendants<Text>()
                                .Where(z => z.Parent is Run || z.Parent is InsertedRun)
                                .StringConcatenate(element => element.Text);
                    else
                        text = i.Element
                                .Descendants<Paragraph>()
                                .StringConcatenate(p => p.Descendants<Text>()
                                                         .Where(z => z.Parent is Run || z.Parent is InsertedRun)
                                                         .StringConcatenate(element => element.Text),
                                                   Environment.NewLine);

                    return new WordDocumentModel
                        {
                            StyleName = i.StyleName,
                            Index = i.Index,
                            Text = text
                        };
                }).ToList();

            var headers = documentModel.Where(
                i => ContainsAnyContent(i.Text, wordDictionary) && i.StyleName.Contains("Heading"))
                                       .Select(i => new HeaderModel
                                           {
                                               HeaderName = i.Text,
                                               HeaderIndex = i.Index
                                           }).ToList();

            var summary = new Dictionary<string, IList<string>>();

            ProcessElements(summary, documentModel, headers.GetEnumerator());

            var obj = JsonConvert.SerializeObject(summary);

            Console.WriteLine(obj);

        }

        /// <summary>
        /// Processes the elements.
        /// </summary>
        /// <param name="summary">The summary.</param>
        /// <param name="documentModel">The document model.</param>
        /// <param name="iterator">The iterator.</param>
        private static void ProcessElements(Dictionary<string, IList<string>> summary, List<WordDocumentModel> documentModel, List<HeaderModel>.Enumerator iterator)
        {
           var current = iterator.Current;

            if (current != null)
            {
                if (summary.ContainsKey(current.HeaderName))
                {
                    return;
                }
                summary.Add(current.HeaderName, null);

                if (iterator.MoveNext())
                {
                    var previous = current;
                    current = iterator.Current;

                    if (current != null)
                        summary[previous.HeaderName] =
                            documentModel.Skip(previous.HeaderIndex + 1)
                                         .Take(current.HeaderIndex - (previous.HeaderIndex + 1))
                                         .Select(a => a.Text)
                                         .ToList();
                    ProcessElements(summary, documentModel, iterator);
                }
                else
                {
                    var lastIndex = documentModel.Last().Index;
                    summary[current.HeaderName] = documentModel.Skip(current.HeaderIndex + 1)
                                         .Take(lastIndex - (current.HeaderIndex + 1))
                                         .Select(a => a.Text)
                                         .ToList();
                 
                }
                
            }
            if (iterator.MoveNext())
            {
                ProcessElements(summary, documentModel, iterator);
            }
        }

        /// <summary>
        /// Determines whether [contains any content] [the specified string to search].
        /// </summary>
        /// <param name="stringToSearch">The string to search.</param>
        /// <param name="searchStrings">The search strings.</param>
        /// <returns></returns>
        public static bool ContainsAnyContent(string stringToSearch, IEnumerable<string> searchStrings)
        {
            return searchStrings.Any(s => stringToSearch.ToLower().Contains(s));
        }

        /// <summary>
        /// Strings the concatenate.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="func">The function.</param>
        /// <returns></returns>
        public static string StringConcatenate<T>(this IEnumerable<T> source, Func<T, string> func)
        {
            var sb = new StringBuilder();
            foreach (var item in source)
                sb.Append(func(item));
            return sb.ToString();
        }

        /// <summary>
        /// Strings the concatenate.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="func">The function.</param>
        /// <param name="separator">The separator.</param>
        /// <returns></returns>
        public static string StringConcatenate<T>(this IEnumerable<T> source,
          Func<T, string> func, string separator)
        {
            var sb = new StringBuilder();
            foreach (var item in source)
                sb.Append(func(item)).Append(separator);
            if (sb.Length > separator.Length)
                sb.Length -= separator.Length;
            return sb.ToString();
        }

    }

    /// <summary>
    /// 
    /// </summary>
    public class  HeaderModel
    {
        /// <summary>
        /// Gets or sets the name of the header.
        /// </summary>
        /// <value>
        /// The name of the header.
        /// </value>
        public string HeaderName { get; set; }
        /// <summary>
        /// Gets or sets the index of the header.
        /// </summary>
        /// <value>
        /// The index of the header.
        /// </value>
        public int HeaderIndex { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class WordDocumentModel
    {
        /// <summary>
        /// Gets or sets the element.
        /// </summary>
        /// <value>
        /// The element.
        /// </value>
        [JsonIgnore]
        public OpenXmlElement Element { get; set; }
        /// <summary>
        /// Gets or sets the name of the style.
        /// </summary>
        /// <value>
        /// The name of the style.
        /// </value>
        public string StyleName { get; set; }
        /// <summary>
        /// Gets or sets the index.
        /// </summary>
        /// <value>
        /// The index.
        /// </value>
        public int Index { get; set; }
        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>
        /// The text.
        /// </value>
        public string Text { get; set; }
    }
}
