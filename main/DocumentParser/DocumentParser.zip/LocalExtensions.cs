﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Math;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Paragraph = DocumentFormat.OpenXml.Wordprocessing.Paragraph;
using Run = DocumentFormat.OpenXml.Wordprocessing.Run;
using Style = DocumentFormat.OpenXml.Wordprocessing.Style;
using StyleValues = DocumentFormat.OpenXml.Wordprocessing.StyleValues;
using Text = DocumentFormat.OpenXml.Wordprocessing.Text;

namespace DocumentParser
{
    public static class LocalExtensions
    {

    }


    class ParserProgram
    {
        static bool ContainsAnyStyles(IEnumerable<string> stylesToSearch,
          IEnumerable<string> searchStrings)
        {
            return stylesToSearch.Intersect(searchStrings).Any();
        }

        static bool ContainsAnyContent(string stringToSearch,
          IEnumerable<string> searchStrings,
          IEnumerable<Regex> regularExpressions, bool isRegularExpression,
          bool caseInsensitive)
        {
            if (isRegularExpression)
                return regularExpressions.Any(r => r.IsMatch(stringToSearch));
            else
                if (caseInsensitive)
                    return searchStrings.Any(
                      s => stringToSearch.ToLower().Contains(s));
                else
                    return searchStrings.Any(s => stringToSearch.Contains(s));
        }

        static IEnumerable<string> GetAllStyleIdsAndNames(
          WordprocessingDocument doc, string styleId)
        {
            string localStyleId = styleId;
            yield return styleId;

            string styleNameForFirstStyle = doc
              .MainDocumentPart
              .StyleDefinitionsPart
              .Styles
              .Elements<Style>()
              .Where(e => e.Type == StyleValues.Paragraph &&
                e.StyleId.Value == styleId)
              .FirstOrDefault()
              .Elements<StyleName>()
              .FirstOrDefault()
              .Val.Value;

            if (styleNameForFirstStyle != null)
                yield return styleNameForFirstStyle;

            while (true)
            {
                Style style = doc
                  .MainDocumentPart
                  .StyleDefinitionsPart
                  .Styles
                  .Elements<Style>()
                  .Where(e => e.Type == StyleValues.Paragraph &&
                    e.StyleId.Value == localStyleId)
                  .FirstOrDefault();

                if (style == null)
                    yield break;

                var basedOn = style
                  .Elements<BasedOn>()
                  .FirstOrDefault();

                if (basedOn == null)
                    yield break;

                yield return basedOn.Val.Value;

                Style basedOnStyle = doc
                  .MainDocumentPart
                  .StyleDefinitionsPart
                  .Styles
                  .Elements<Style>()
                  .Where(e => e.Type == StyleValues.Paragraph &&
                    e.StyleId.Value == basedOn.Val.Value)
                  .FirstOrDefault();

                var basedOnStyleName = style
                  .Elements<StyleName>()
                  .FirstOrDefault()
                  .Val.Value;

                if (basedOnStyleName != null)
                    yield return basedOnStyleName;

                localStyleId = basedOn.Val.Value;
            }
        }

        static int[] SearchInDocument(WordprocessingDocument doc,
          IEnumerable<string> styleSearchString,
          IEnumerable<string> contentSearchString,
          bool isRegularExpression, bool caseInsensitive)
        {
            RegexOptions options;
            Regex[] regularExpressions = null;
            if (isRegularExpression && contentSearchString != null)
            {
                if (caseInsensitive)
                    options = RegexOptions.IgnoreCase | RegexOptions.Compiled;
                else
                    options = RegexOptions.Compiled;
                regularExpressions = contentSearchString
                  .Select(s => new Regex(s, options)).ToArray();
            }

            string[] contentSearchStringToUse = null;
            if (contentSearchString != null)
            {
                if (!isRegularExpression && caseInsensitive)
                    contentSearchStringToUse =
                      contentSearchString.Select(s => s.ToLower()).ToArray();
                else
                    contentSearchStringToUse = contentSearchString.ToArray();
            }

            var defaultStyleName = doc
                .MainDocumentPart
                .StyleDefinitionsPart
                .Styles
                .Elements<Style>().First(style => style.Type == StyleValues.Paragraph 
                                                        && style.Default == OnOffValue.FromBoolean(true)
                                                  )
              .StyleId.Value;

            var q1 = doc
              .MainDocumentPart
              .Document
              .Body
              .Elements()
              .Select((p, i) =>
              {
                  var styleNode = p
                    .Descendants<ParagraphStyleId>()
                    .FirstOrDefault();
                  var styleName = styleNode != null ?
                    styleNode.Val.Value :
                    defaultStyleName;
                  return new
                  {
                      Element = p,
                      Index = i,
                      StyleName = styleName
                  };
              }
              );

            var q2 = q1
              .Select(i =>
              {
                  string text = null;
                  if (i.Element is Paragraph)
                      text = i.Element
                        .Descendants<Text>()
                        .Where(z => z.Parent is Run || z.Parent is InsertedRun)
                        .StringConcatenate(element => element.Text);
                  else
                      text = i.Element
                        .Descendants<Paragraph>()
                        .StringConcatenate(p => p
                          .Descendants<Text>()
                          .Where(z => z.Parent is Run || z.Parent is InsertedRun)
                          .StringConcatenate(element => element.Text),
                          Environment.NewLine);

                  return new
                  {
                      Element = i.Element,
                      StyleName = i.StyleName,
                      Index = i.Index,
                      Text = text
                  };
              }
              );

            var q3 = q2
              .Select(i =>
                new
                {
                    Element = i.Element,
                    StyleName = i.StyleName,
                    Index = i.Index,
                    Text = i.Text,
                    InheritedStyles =
                      GetAllStyleIdsAndNames(doc, i.StyleName).Distinct()
                }
              );

            int[] q4 = null;
            if (styleSearchString != null)
                q4 = q3
                  .Where(i => ContainsAnyStyles(
                    i.InheritedStyles, styleSearchString))
                  .Select(i => i.Index)
                  .ToArray();

            int[] q5 = null;
            if (contentSearchStringToUse != null)
                q5 = q3
                  .Where(i => ContainsAnyContent(
                    i.Text, contentSearchStringToUse, regularExpressions,
                    isRegularExpression, caseInsensitive))
                  .Select(i => i.Index)
                  .ToArray();

            int[] q6 = null;
            if (q4 != null && q5 != null)
                q6 = q4.Intersect(q5).ToArray();
            else
                q6 = q5 != null ? q5 : q4;

            return q6;
        }


        public static int[] SearchInDocument(string filename,
          IEnumerable<string> styleSearchString,
          IEnumerable<string> contentSearchString,
          bool isRegularExpression, bool caseInsensitive)
        {
            using (WordprocessingDocument doc =
              WordprocessingDocument.Open(filename, false))

                return SearchInDocument(doc, styleSearchString,
                  contentSearchString, isRegularExpression, caseInsensitive);
        }

        static int[] SearchInDocument(string filename,
          string styleSearchString, string contentSearchString,
          bool isRegularExpression, bool caseInsensitive)
        {
            return SearchInDocument(filename,
              styleSearchString != null ?
                new List<string>() { styleSearchString } : null,
              contentSearchString != null ?
                new List<string>() { contentSearchString } : null,
              isRegularExpression, caseInsensitive);
        }

        static void MyMain()
        {
            string fileToSearch = @"C:\Laptop Backup\Pritam\Docs\Resume_Pritam Paul.docx";

            Console.WriteLine("Using Open XML Format SDK 2.0");
            Console.WriteLine("-----------------------------");

            Console.WriteLine("Test 1");
            int[] results1 = SearchInDocument(
              fileToSearch, new[] { "Normal" }, new[] { "h.*o", "aaa" },
              true, false);
            foreach (var i in results1) Console.WriteLine(i);
            Console.WriteLine(results1.SequenceEqual(new[] { 7, 10 }) ?
              "Passed" : "Failed");
            Console.WriteLine();

            Console.WriteLine("Test 2");
            int[] results2 = SearchInDocument(
              fileToSearch, new[] { "NotAStyle" }, new[] { "h.*o", "aaa" },
              true, false);
            foreach (var i in results2) Console.WriteLine(i);
            Console.WriteLine(results2.SequenceEqual(new int[] { }) ?
              "Passed" : "Failed");
            Console.WriteLine();

            Console.WriteLine("Test 3");
            int[] results3 = SearchInDocument(
              fileToSearch, new[] { "Heading1" }, null, true, false);
            foreach (var i in results3) Console.WriteLine(i);
            Console.WriteLine(results3.SequenceEqual(new int[] { 0 }) ?
              "Passed" : "Failed");
            Console.WriteLine();

            Console.WriteLine("Test 4");
            int[] results4 = SearchInDocument(
              fileToSearch, new[] { "Normal" }, new[] { "h.*o", "aaa" },
              true, true);
            foreach (var i in results4) Console.WriteLine(i);
            Console.WriteLine(
              results4.SequenceEqual(new int[] { 0, 6, 7, 8, 10 }) ?
              "Passed" : "Failed");
            Console.WriteLine();

            Console.WriteLine("Test 5");
            int[] results5 = SearchInDocument(
              fileToSearch, null, new[] { "hello", "aaa" }, false, false);
            foreach (var i in results5) Console.WriteLine(i);
            Console.WriteLine(
              results5.SequenceEqual(new int[] { 7, 10 }) ?
              "Passed" : "Failed");
            Console.WriteLine();

            Console.WriteLine("Test 6");
            int[] results6 = SearchInDocument(
              fileToSearch, null, new[] { "hello", "aaa" }, false, true);
            foreach (var i in results6) Console.WriteLine(i);
            Console.WriteLine(
              results6.SequenceEqual(new int[] { 0, 6, 7, 8, 10 }) ?
              "Passed" : "Failed");
            Console.WriteLine();

            Console.WriteLine("Test 7");
            int[] results7 = SearchInDocument(fileToSearch, "Heading1", "Aaa",
              false, false);
            foreach (var i in results7) Console.WriteLine(i);
            Console.WriteLine(results7.SequenceEqual(new int[] { 0 }) ?
              "Passed" : "Failed");
            Console.WriteLine();
        }
    }
}
